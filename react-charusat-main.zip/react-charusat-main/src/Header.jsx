function Header(){
    return (<div>
        <h1>This is Header 1</h1>
    </div>)
}
export default Header